package org.cibertec.pe.services;

import java.util.List;

import org.cibertec.pe.interfaceServices.IEmpleadosServices;
import org.cibertec.pe.interfaces.IEmpleados;
import org.cibertec.pe.modelo.Empleados;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmpleadosServices implements IEmpleadosServices{
	
	@Autowired
	private IEmpleados data;
	
	@Override
	public List<Empleados> Listado() {
		return (List<Empleados>)data.findAll();
		
	}
	
	@Override
	public int grabar(Empleados e) {
		int res = 0;
		Empleados emple = data.save(e);
		if(!emple.equals(null)) res = 1;
		return res;
	}
	
}
