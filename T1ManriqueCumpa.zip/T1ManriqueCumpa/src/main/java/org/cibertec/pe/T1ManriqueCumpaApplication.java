package org.cibertec.pe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class T1ManriqueCumpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(T1ManriqueCumpaApplication.class, args);
	}

}
