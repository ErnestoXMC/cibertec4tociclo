package org.cibertec.pe.interfaceServices;

import java.util.List;

import org.cibertec.pe.modelo.Empleados;

public interface IEmpleadosServices {
	
	public List<Empleados> Listado();
	public int grabar(Empleados e);

}
