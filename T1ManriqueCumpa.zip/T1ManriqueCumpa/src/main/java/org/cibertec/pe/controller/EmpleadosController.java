package org.cibertec.pe.controller;

import java.util.List;

import org.cibertec.pe.interfaceServices.IEmpleadosServices;
import org.cibertec.pe.modelo.Empleados;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EmpleadosController {

	@Autowired
	private IEmpleadosServices service;
	
	@GetMapping("/listar")
	public String listadoEmpleados(Model m) {
		
		List<Empleados> listEmple = service.Listado();
		m.addAttribute("lista", listEmple);
		return "index";
	}
	// Método agregar
		@GetMapping("/nuevo")
		public String agregar(Model m) {
		m.addAttribute("empleado", new Empleados());
		return "form";
		}
		// Método grabar
		@GetMapping("/salvar")
		public String salvar(Empleados e, Model m) {
		service.grabar(e);
		return "redirect:/listar";
		}
}
