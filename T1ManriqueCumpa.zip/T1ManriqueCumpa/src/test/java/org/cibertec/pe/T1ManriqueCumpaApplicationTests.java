package org.cibertec.pe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T1ManriqueCumpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
